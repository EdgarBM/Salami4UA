
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using Salami4UAGenNHibernate.EN.Salami4UA;
using Salami4UAGenNHibernate.CAD.Salami4UA;

namespace Salami4UAGenNHibernate.CEN.Salami4UA
{
public partial class GenreFilmsCEN
{
public void DameTodosLosGenerosCine (string p_oid)
{
        /*PROTECTED REGION ID(Salami4UAGenNHibernate.CEN.Salami4UA_GenreFilms_dameTodosLosGenerosCine) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method DameTodosLosGenerosCine() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}
