
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using Salami4UAGenNHibernate.EN.Salami4UA;
using Salami4UAGenNHibernate.CAD.Salami4UA;

namespace Salami4UAGenNHibernate.CEN.Salami4UA
{
public partial class UserCEN
{
public System.Collections.Generic.IList<Salami4UAGenNHibernate.EN.Salami4UA.UserEN> DameUsuarioPorAltura (int altura)
{
        /*PROTECTED REGION ID(Salami4UAGenNHibernate.CEN.Salami4UA_User_dameUsuarioPorAltura) ENABLED START*/

        // Write here your custom code...

        UserCEN usuariocen = new UserCEN ();

        System.Collections.Generic.IList<Salami4UAGenNHibernate.EN.Salami4UA.UserEN> todosUsuarios = usuariocen.DameTodosLosUsuarios ();
        System.Collections.Generic.IList<Salami4UAGenNHibernate.EN.Salami4UA.UserEN> resultado = usuariocen.DameTodosLosUsuarios ();
        while (resultado.Count != 0) {
                resultado.RemoveAt (0);
        }

        foreach (UserEN usuario in todosUsuarios) {
                if (usuario.Height_0.Height == altura) {
                        resultado.Add (usuario);
                }
        }

        return resultado;

        /*PROTECTED REGION END*/
}
}
}
