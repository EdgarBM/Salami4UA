
using System;

namespace Salami4UAGenNHibernate.Enumerated.Salami4UA
{
public enum HairStyleEnum { Straight=1, Curly=2 };
}
