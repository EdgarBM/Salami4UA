
using System;

namespace Salami4UAGenNHibernate.Enumerated.Salami4UA
{
public enum EyeColorEnum { Blue=1, Green=2, Brown=3, Grey=4, Black=5, Hazel=6, Other=7 };
}
