
using System;

namespace Salami4UAGenNHibernate.Enumerated.Salami4UA
{
public enum HeightEnum { 140=1, 145=2, 150=3, 155=4, 160=5, 165=6, 170=7, 175=8, 180=9, 185=10, 195=11, 200=12, 205=13, 210=14, 215=15, 220=16 };
}
