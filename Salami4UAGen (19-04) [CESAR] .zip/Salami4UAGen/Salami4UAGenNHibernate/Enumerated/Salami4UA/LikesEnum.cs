
using System;

namespace Salami4UAGenNHibernate.Enumerated.Salami4UA
{
public enum LikesEnum { Man=1, Woman=2, Both=3 };
}
