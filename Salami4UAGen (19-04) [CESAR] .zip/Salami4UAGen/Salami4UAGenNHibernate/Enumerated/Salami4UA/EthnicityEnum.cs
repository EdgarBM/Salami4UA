
using System;

namespace Salami4UAGenNHibernate.Enumerated.Salami4UA
{
public enum EthnicityEnum { European=1, Arab=2, African=3, Mediterranean=4, Asian=5, Indian=6, Latino=7, Mestizo=8, Secret=9 };
}
