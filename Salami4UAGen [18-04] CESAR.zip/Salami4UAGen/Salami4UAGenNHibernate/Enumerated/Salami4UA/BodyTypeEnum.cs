
using System;

namespace Salami4UAGenNHibernate.Enumerated.Salami4UA
{
public enum BodyTypeEnum { Normal=1, Sports=2, Slim=3, Corpulent=4, Solidly=5, Secret=6 };
}
