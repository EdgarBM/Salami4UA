
using System;

namespace Salami4UAGenNHibernate.Enumerated.Salami4UA
{
public enum HairLengthEnum { Short=1, Normal=2, Long=3, Shaven=4, Hairless=5 };
}
