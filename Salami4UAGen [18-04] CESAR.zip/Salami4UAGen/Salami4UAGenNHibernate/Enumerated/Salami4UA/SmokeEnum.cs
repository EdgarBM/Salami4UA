
using System;

namespace Salami4UAGenNHibernate.Enumerated.Salami4UA
{
public enum SmokeEnum { Occasionally=1, Often=2, No=3 };
}
