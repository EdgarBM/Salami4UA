
using System;

namespace Salami4UAGenNHibernate.Enumerated.Salami4UA
{
public enum HairColorEnum { LightBrown=1, DarkBrown=2, Brown=3, Blonde=4, Redhead=5, White=6, Gray=7, Other=8 };
}
