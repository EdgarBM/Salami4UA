
using System;

namespace Salami4UAGenNHibernate.Enumerated.Salami4UA
{
public enum GenderEnum { Man=1, Woman=2 };
}
