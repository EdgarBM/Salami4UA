
using System;

namespace Salami4UAGenNHibernate.Enumerated.Salami4UA
{
public enum ReligionEnum { Agnostic=1, Atheist=2, Buddhist=3, Catholic=4, Christian=5, Spiritualistic=6, Hindu=7, Jewish=8, Muslim=9, Orthodox=10, Protestant=11, Other=12, Secret=13 };
}
